import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import ProtectedRoute  from './components/ProtectedRoute'
import Layout          from './components/Layout'
import Login           from './pages/Login'
import Overview        from './pages/Overview'
import Appointments    from './pages/Appointments'
import Clients         from './pages/Clients'
import ClientDetail    from './pages/ClientDetail'
import Revenue         from './pages/Revenue'
import Settings        from './pages/Settings'

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ThemeProvider>
          <Routes>
            <Route path="/login" element={<Login />} />

            <Route element={<ProtectedRoute />}>
              <Route element={<Layout />}>
                <Route index element={<Navigate to="/overview" replace />} />
                <Route path="/overview"              element={<Overview />} />
                <Route path="/appointments"          element={<Appointments />} />
                <Route path="/clients"               element={<Clients />} />
                <Route path="/clients/:id"           element={<ClientDetail />} />
                <Route path="/revenue"               element={<Revenue />} />
                <Route path="/settings"              element={<Settings />} />
              </Route>
            </Route>

            <Route path="*" element={<Navigate to="/overview" replace />} />
          </Routes>
        </ThemeProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}
