export default function WidgetCard({ title, children, dragHandleProps, editMode, widgetId, onToggleHide, hidden }) {
  return (
    <div className={`bg-gray-900 border border-gray-800 rounded-xl flex flex-col ${hidden ? 'opacity-50' : ''}`}>
      {/* Widget header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
        <div className="flex items-center gap-2">
          {editMode && dragHandleProps && (
            <button
              {...dragHandleProps}
              className="text-gray-600 hover:text-gray-400 cursor-grab active:cursor-grabbing transition-colors touch-none"
              title="Drag to reorder"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/>
                <circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/>
                <circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/>
              </svg>
            </button>
          )}
          <h3 className="text-sm font-semibold text-white">{title}</h3>
        </div>
        {editMode && (
          <button
            onClick={() => onToggleHide(widgetId)}
            className={`text-xs px-2 py-1 rounded-md transition-colors font-medium ${
              hidden
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:bg-amber-500/20'
                : 'bg-gray-800 text-gray-400 border border-gray-700 hover:text-white hover:bg-gray-700'
            }`}
          >
            {hidden ? 'Show' : 'Hide'}
          </button>
        )}
      </div>
      {/* Widget body */}
      <div className="flex-1 p-4">
        {children}
      </div>
    </div>
  )
}
