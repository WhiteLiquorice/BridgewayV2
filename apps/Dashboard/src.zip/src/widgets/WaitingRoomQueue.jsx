import { useState } from 'react'

// TODO: Move to a shared Supabase table (e.g., waiting_room) for multi-device access in a future phase.
// Currently local state only — per the spec, this is a manual queue for front-desk use on a single device.

const STATUS_CYCLE = ['Waiting', 'With Provider', 'Done']

const statusStyles = {
  'Waiting': 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  'With Provider': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'Done': 'bg-green-500/10 text-green-400 border-green-500/20',
}

let nextId = 1

export default function WaitingRoomQueue() {
  const [queue, setQueue] = useState([])
  const [inputName, setInputName] = useState('')

  function addPatient() {
    const name = inputName.trim()
    if (!name) return
    setQueue(q => [...q, { id: nextId++, name, status: 'Waiting' }])
    setInputName('')
  }

  function cycleStatus(id) {
    setQueue(q => q.map(p => {
      if (p.id !== id) return p
      const currentIdx = STATUS_CYCLE.indexOf(p.status)
      const nextIdx = (currentIdx + 1) % STATUS_CYCLE.length
      // If cycling past 'Done', remove the patient
      if (p.status === 'Done') return null
      return { ...p, status: STATUS_CYCLE[nextIdx] }
    }).filter(Boolean))
  }

  function removePatient(id) {
    setQueue(q => q.filter(p => p.id !== id))
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') addPatient()
  }

  return (
    <div className="space-y-3">
      {/* Add patient input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={inputName}
          onChange={e => setInputName(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Patient name..."
          className="flex-1 bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 placeholder-gray-600 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/20"
        />
        <button
          onClick={addPatient}
          disabled={!inputName.trim()}
          className="px-3 py-2 bg-amber-500 text-[#0c1a2e] text-sm font-medium rounded-lg hover:bg-amber-400 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Add
        </button>
      </div>

      {/* Queue list */}
      {queue.length === 0 ? (
        <p className="text-gray-600 text-sm text-center py-4">Queue is empty</p>
      ) : (
        <div className="space-y-1.5">
          {queue.map(patient => (
            <div
              key={patient.id}
              className={`flex items-center justify-between gap-2 p-2.5 rounded-lg bg-gray-800/50 ${patient.status === 'Done' ? 'opacity-60' : ''}`}
            >
              <span className={`text-sm font-medium ${patient.status === 'Done' ? 'line-through text-gray-500' : 'text-white'}`}>
                {patient.name}
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => cycleStatus(patient.id)}
                  className={`text-xs px-2 py-0.5 rounded border font-medium transition-colors ${statusStyles[patient.status]}`}
                  title="Click to advance status"
                >
                  {patient.status}
                </button>
                <button
                  onClick={() => removePatient(patient.id)}
                  className="text-gray-600 hover:text-red-400 transition-colors p-0.5"
                  title="Remove"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
