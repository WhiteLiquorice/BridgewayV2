import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

const statusStyles = {
  confirmed: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  completed: 'bg-green-500/10 text-green-400 border-green-500/20',
  cancelled: 'bg-red-500/10 text-red-400 border-red-500/20',
  pending: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
}

export default function TodaySchedule() {
  const { profile } = useAuth()
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    if (!profile?.org_id) return
    fetchToday()
  }, [profile?.org_id])

  async function fetchToday() {
    setLoading(true)
    setError(false)
    const today = new Date()
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate()).toISOString()
    const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59).toISOString()

    try {
      const { data } = await supabase
        .from('appointments')
        .select('id, scheduled_at, status, amount, clients(name), services(name, duration_minutes)')
        .eq('org_id', profile.org_id)
        .gte('scheduled_at', startOfDay)
        .lte('scheduled_at', endOfDay)
        .neq('status', 'cancelled')
        .order('scheduled_at')

      setAppointments(data || [])
    } catch {
      setError(true)
      setAppointments([])
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (error) {
    return (
      <p className="text-red-400/70 text-sm text-center py-6">Unable to load — try refreshing</p>
    )
  }

  if (appointments.length === 0) {
    return (
      <p className="text-gray-500 text-sm text-center py-6">No appointments today</p>
    )
  }

  return (
    <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
      <div className="flex items-center gap-2 mb-3">
        <span className="text-xs text-gray-500">{appointments.length} appointment{appointments.length !== 1 ? 's' : ''} today</span>
      </div>
      {appointments.map(appt => {
        const time = new Date(appt.scheduled_at).toLocaleTimeString('en-US', {
          hour: 'numeric', minute: '2-digit', hour12: true,
        })
        const duration = appt.services?.duration_minutes
        const statusStyle = statusStyles[appt.status] || 'bg-gray-500/10 text-gray-400 border-gray-500/20'
        return (
          <div
            key={appt.id}
            className="flex items-start justify-between gap-3 p-2.5 rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors"
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{appt.clients?.name ?? '—'}</p>
              <p className="text-xs text-gray-500 truncate">
                {appt.services?.name ?? '—'}
                {duration ? ` · ${duration} min` : ''}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1 flex-shrink-0">
              <p className="text-xs font-medium text-gray-300 tabular-nums">{time}</p>
              <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium border ${statusStyle}`}>
                {appt.status.charAt(0).toUpperCase() + appt.status.slice(1)}
              </span>
            </div>
          </div>
        )
      })}
    </div>
  )
}
