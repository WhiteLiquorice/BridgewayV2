import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { WIDGET_IDS, canRoleSeeWidget } from './registry'

const LS_KEY = 'bw_widget_config'

function getDefaultConfig(role) {
  const hidden = []
  // Revenue is hidden by default for staff
  if (role === 'staff') hidden.push('revenue')
  // Filter order to only include widgets this role can see
  const order = WIDGET_IDS.filter(id => canRoleSeeWidget(id, role))
  return { order, hidden }
}

export function useWidgetConfig(user, role) {
  const [config, setConfig] = useState(null)
  const [loading, setLoading] = useState(true)

  // Load config: try Supabase first, fall back to localStorage
  useEffect(() => {
    if (!user) { setLoading(false); return }
    async function load() {
      setLoading(true)
      try {
        // Try Supabase widget_configs table
        // TODO: migrate to org_id once schema migration is applied
        const { data } = await supabase
          .from('widget_configs')
          .select('config')
          .eq('user_id', user.id)
          .maybeSingle()

        if (data?.config && data.config.order) {
          setConfig(data.config)
        } else {
          // Fall back to localStorage
          const stored = localStorage.getItem(LS_KEY + '_' + user.id)
          setConfig(stored ? JSON.parse(stored) : getDefaultConfig(role))
        }
      } catch {
        // If Supabase fails (table not created yet), use localStorage
        const stored = localStorage.getItem(LS_KEY + '_' + user.id)
        setConfig(stored ? JSON.parse(stored) : getDefaultConfig(role))
      }
      setLoading(false)
    }
    load()
  }, [user, role])

  // Save config to both localStorage and Supabase
  const saveConfig = useCallback(async (newConfig) => {
    if (!user) return
    setConfig(newConfig)
    // Always save to localStorage immediately
    localStorage.setItem(LS_KEY + '_' + user.id, JSON.stringify(newConfig))
    // Best-effort Supabase sync
    try {
      await supabase
        .from('widget_configs')
        .upsert({ user_id: user.id, config: newConfig, updated_at: new Date().toISOString() })
    } catch {
      // Supabase sync failed — localStorage is the fallback, no action needed
    }
  }, [user])

  const reorder = useCallback((newOrder) => {
    const newConfig = { ...config, order: newOrder }
    saveConfig(newConfig)
  }, [config, saveConfig])

  const toggleHidden = useCallback((widgetId) => {
    const hidden = config?.hidden || []
    const newHidden = hidden.includes(widgetId)
      ? hidden.filter(id => id !== widgetId)
      : [...hidden, widgetId]
    saveConfig({ ...config, hidden: newHidden })
  }, [config, saveConfig])

  const isHidden = useCallback((widgetId) => {
    return config?.hidden?.includes(widgetId) ?? false
  }, [config])

  return { config, loading, reorder, toggleHidden, isHidden }
}
