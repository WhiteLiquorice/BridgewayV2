import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

// TODO: Move status tracking to a shared Supabase table for multi-device in a future phase.
// Currently using localStorage per-device.

const STATUS_OPTIONS = ['In Office', 'On Lunch', 'On Break', 'Out']

const statusStyles = {
  'In Office': 'bg-green-500/10 text-green-400 border-green-500/20',
  'On Lunch': 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  'On Break': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'Out': 'bg-gray-500/10 text-gray-400 border-gray-700',
}

const roleLabels = {
  admin: 'Admin',
  manager: 'Manager',
  staff: 'Staff',
}

const LS_ROSTER_KEY = 'bw_staff_roster_status'

function loadStatuses() {
  try {
    return JSON.parse(localStorage.getItem(LS_ROSTER_KEY) || '{}')
  } catch {
    return {}
  }
}

function saveStatuses(statuses) {
  localStorage.setItem(LS_ROSTER_KEY, JSON.stringify(statuses))
}

export default function StaffRoster() {
  const { profile } = useAuth()
  const [staffList, setStaffList] = useState([])
  const [statuses, setStatuses] = useState(loadStatuses())
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    if (!profile?.org_id) return
    fetchStaff()
  }, [profile?.org_id])

  async function fetchStaff() {
    setLoading(true)
    setError(false)
    try {
      const { data } = await supabase
        .from('profiles')
        .select('id, full_name, role, email')
        .eq('org_id', profile.org_id)
        .limit(10)

      setStaffList(data || [])
    } catch {
      setError(true)
      setStaffList([])
    } finally {
      setLoading(false)
    }
  }

  function handleStatusChange(profileId, newStatus) {
    const updated = { ...statuses, [profileId]: newStatus }
    setStatuses(updated)
    saveStatuses(updated)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (error) {
    return (
      <p className="text-red-400/70 text-sm text-center py-6">Unable to load — try refreshing</p>
    )
  }

  if (staffList.length === 0) {
    return (
      <p className="text-gray-500 text-sm text-center py-6">No staff profiles found</p>
    )
  }

  return (
    <div className="space-y-2">
      {staffList.map(member => {
        const currentStatus = statuses[member.id] || 'In Office'
        return (
          <div
            key={member.id}
            className="flex items-center justify-between gap-3 p-2.5 rounded-lg bg-gray-800/50"
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{member.full_name || member.email || '—'}</p>
              <span className={`inline-block text-xs px-1.5 py-0.5 rounded font-medium mt-0.5 bg-gray-700/50 text-gray-400`}>
                {roleLabels[member.role] || member.role}
              </span>
            </div>
            <select
              value={currentStatus}
              onChange={e => handleStatusChange(member.id, e.target.value)}
              className={`text-xs px-2 py-1 rounded-md border font-medium bg-transparent cursor-pointer focus:outline-none ${statusStyles[currentStatus]}`}
            >
              {STATUS_OPTIONS.map(opt => (
                <option key={opt} value={opt} className="bg-gray-900 text-white">{opt}</option>
              ))}
            </select>
          </div>
        )
      })}
    </div>
  )
}
