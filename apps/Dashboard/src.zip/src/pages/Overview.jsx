import WidgetCanvas from '../widgets/WidgetCanvas'

export default function Overview() {
  return <WidgetCanvas />
}
