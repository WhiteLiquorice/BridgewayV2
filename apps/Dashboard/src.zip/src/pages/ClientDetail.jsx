import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

const statusStyles = {
  pending:   'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  confirmed: 'bg-blue-500/10  text-blue-400   border-blue-500/20',
  completed: 'bg-green-500/10 text-green-400  border-green-500/20',
  cancelled: 'bg-red-500/10   text-red-400    border-red-500/20',
}

export default function ClientDetail() {
  const { id }         = useParams()
  const { profile }    = useAuth()
  const navigate       = useNavigate()
  const [client,       setClient]       = useState(null)
  const [appointments, setAppointments] = useState([])
  const [loading,      setLoading]      = useState(true)

  useEffect(() => {
    if (!profile?.org_id || !id) return
    fetchClient()
  }, [profile?.org_id, id])

  async function fetchClient() {
    setLoading(true)
    try {
      const { data: clientData } = await supabase
        .from('clients')
        .select('*')
        .eq('id', id)
        .eq('org_id', profile.org_id)
        .maybeSingle()

      const { data: apptData } = await supabase
        .from('appointments')
        .select('id, scheduled_at, status, amount, notes, services(name)')
        .eq('client_id', id)
        .eq('org_id', profile.org_id)
        .order('scheduled_at', { ascending: false })

      setClient(clientData)
      setAppointments(apptData || [])
    } catch {
      setClient(null)
      setAppointments([])
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-7 h-7 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!client) {
    return (
      <div className="p-6">
        <p className="text-gray-400">Client not found.</p>
        <button onClick={() => navigate('/clients')} className="mt-4 text-sm text-amber-400 hover:text-amber-300">
          ← Back to clients
        </button>
      </div>
    )
  }

  const totalSpent   = appointments.filter(a => a.status !== 'cancelled').reduce((s, a) => s + Number(a.amount || 0), 0)
  const totalAppts   = appointments.filter(a => a.status !== 'cancelled').length

  return (
    <div className="p-6 space-y-6">
      {/* Back */}
      <button
        onClick={() => navigate('/clients')}
        className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-white transition-colors"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
        Back to clients
      </button>

      {/* Client card */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <div className="flex items-start gap-5">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center flex-shrink-0">
            <span className="text-xl font-bold text-amber-400">
              {client.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-semibold text-white">{client.name}</h1>
            <div className="mt-2 flex flex-wrap gap-x-6 gap-y-1">
              {client.email && (
                <span className="text-sm text-gray-400">{client.email}</span>
              )}
              {client.phone && (
                <span className="text-sm text-gray-400">{client.phone}</span>
              )}
              <span className="text-sm text-gray-500">
                Client since {new Date(client.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </span>
            </div>
            {client.notes && (
              <p className="mt-3 text-sm text-gray-500 italic">{client.notes}</p>
            )}
          </div>
        </div>

        {/* Mini stats */}
        <div className="mt-5 pt-5 border-t border-gray-800 grid grid-cols-2 sm:grid-cols-3 gap-4">
          <div>
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Total visits</p>
            <p className="mt-1 text-2xl font-bold text-white">{totalAppts}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Total spent</p>
            <p className="mt-1 text-2xl font-bold text-white">${totalSpent.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Last visit</p>
            <p className="mt-1 text-lg font-semibold text-white">
              {appointments.length > 0
                ? new Date(appointments[0].scheduled_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                : '—'}
            </p>
          </div>
        </div>
      </div>

      {/* Appointment history */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-800">
          <h2 className="text-sm font-semibold text-white">Appointment History</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="text-right px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/60">
              {appointments.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-5 py-10 text-center text-gray-500">
                    No appointments on record
                  </td>
                </tr>
              ) : (
                appointments.map(appt => (
                  <tr key={appt.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="px-5 py-3.5 text-gray-200">{appt.services?.name ?? '—'}</td>
                    <td className="px-5 py-3.5 text-gray-400">
                      {new Date(appt.scheduled_at).toLocaleDateString('en-US', {
                        month: 'short', day: 'numeric', year: 'numeric',
                        hour: 'numeric', minute: '2-digit'
                      })}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${statusStyles[appt.status] ?? ''}`}>
                        {appt.status.charAt(0).toUpperCase() + appt.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right text-gray-200 font-medium tabular-nums">
                      ${Number(appt.amount || 0).toFixed(2)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
