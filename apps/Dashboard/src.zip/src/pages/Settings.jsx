import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

function Section({ title, children }) {
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-800">
        <h2 className="text-sm font-semibold text-white">{title}</h2>
      </div>
      <div className="p-6">{children}</div>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-400 mb-1.5">{label}</label>
      {children}
    </div>
  )
}

function SaveButton({ loading, saved, label = 'Save changes' }) {
  return (
    <div className="flex items-center gap-3 pt-1">
      <button
        type="submit"
        disabled={loading}
        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-[#080f1d] text-sm font-semibold rounded-lg disabled:opacity-50 transition-colors"
      >
        {loading ? 'Saving…' : label}
      </button>
      {saved && (
        <span className="text-sm text-green-400 flex items-center gap-1.5">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
          Saved
        </span>
      )}
    </div>
  )
}

const inputCls = "w-full px-3.5 py-2.5 bg-[#0c1a2e] border border-gray-700 rounded-lg text-sm text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50 transition-colors"

export default function Settings() {
  // profile and org come from AuthContext — already loaded, no extra fetch needed
  const { profile, org } = useAuth()

  const canEdit = profile?.role === 'admin' || profile?.role === 'manager'

  // ── My Profile ──────────────────────────────────────────────────────────────
  const [fullName,      setFullName]      = useState('')
  const [profileEmail,  setProfileEmail]  = useState('')
  const [profilePhone,  setProfilePhone]  = useState('')
  const [profileSaved,  setProfileSaved]  = useState(false)
  const [profileLoading, setProfileLoading] = useState(false)

  // Seed form from context once profile arrives
  useEffect(() => {
    if (!profile) return
    setFullName(profile.full_name  ?? '')
    setProfileEmail(profile.email  ?? '')
    setProfilePhone(profile.phone  ?? '')
  }, [profile?.id])

  async function saveProfile(e) {
    e.preventDefault()
    setProfileLoading(true)
    setProfileSaved(false)
    try {
      await supabase
        .from('profiles')
        .update({ full_name: fullName, email: profileEmail, phone: profilePhone })
        .eq('id', profile.id)
      setProfileSaved(true)
      setTimeout(() => setProfileSaved(false), 3000)
    } catch {
      // silent
    } finally {
      setProfileLoading(false)
    }
  }

  // ── Clinic Info (admin/manager only) ────────────────────────────────────────
  const [orgName,    setOrgName]    = useState('')
  const [orgSaved,   setOrgSaved]   = useState(false)
  const [orgLoading, setOrgLoading] = useState(false)

  useEffect(() => {
    if (!org) return
    setOrgName(org.name ?? '')
  }, [org?.id])

  async function saveOrg(e) {
    e.preventDefault()
    setOrgLoading(true)
    setOrgSaved(false)
    try {
      await supabase
        .from('orgs')
        .update({ name: orgName })
        .eq('id', org.id)
      setOrgSaved(true)
      setTimeout(() => setOrgSaved(false), 3000)
    } catch {
      // silent
    } finally {
      setOrgLoading(false)
    }
  }

  // ── Services (admin/manager only) ───────────────────────────────────────────
  const [services,       setServices]      = useState([])
  const [svcLoading,     setSvcLoading]    = useState(true)
  const [newSvcName,     setNewSvcName]    = useState('')
  const [newSvcDuration, setNewSvcDuration] = useState(60)
  const [newSvcPrice,    setNewSvcPrice]   = useState('')
  const [addingSvc,      setAddingSvc]     = useState(false)
  const [deleteConfirm,  setDeleteConfirm] = useState(null)

  useEffect(() => {
    if (!profile?.org_id) return
    fetchServices()
  }, [profile?.org_id])

  async function fetchServices() {
    setSvcLoading(true)
    try {
      const { data } = await supabase
        .from('services')
        .select('id, name, price, duration_minutes, is_archived')
        .eq('org_id', profile.org_id)
        .eq('is_archived', false)
        .order('name', { ascending: true })
      setServices(data || [])
    } catch {
      setServices([])
    } finally {
      setSvcLoading(false)
    }
  }

  async function addService(e) {
    e.preventDefault()
    if (!newSvcName.trim()) return
    setAddingSvc(true)
    try {
      const { data } = await supabase
        .from('services')
        .insert({
          org_id:           profile.org_id,
          name:             newSvcName.trim(),
          duration_minutes: Number(newSvcDuration),
          price:            Number(newSvcPrice) || 0,
        })
        .select('id, name, price, duration_minutes, is_archived')
        .single()
      if (data) setServices(prev => [...prev, data])
      setNewSvcName('')
      setNewSvcDuration(60)
      setNewSvcPrice('')
    } catch {
      // silent
    } finally {
      setAddingSvc(false)
    }
  }

  async function archiveService(id) {
    try {
      await supabase
        .from('services')
        .update({ is_archived: true })
        .eq('id', id)
        .eq('org_id', profile.org_id)
      setServices(prev => prev.filter(s => s.id !== id))
    } catch {
      // silent
    } finally {
      setDeleteConfirm(null)
    }
  }

  // Wait for context to arrive (AuthContext handles the spinner until then)
  if (!profile || !org) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-7 h-7 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6 max-w-2xl">
      <div>
        <h1 className="text-xl font-semibold text-white">Settings</h1>
        <p className="text-sm text-gray-500 mt-0.5">
          {profile.full_name || profile.email} · {org.name}
        </p>
      </div>

      {/* My Profile */}
      <Section title="My Profile">
        <form onSubmit={saveProfile} className="space-y-4">
          <Field label="Full name">
            <input
              type="text"
              value={fullName}
              onChange={e => setFullName(e.target.value)}
              placeholder="Jane Smith"
              className={inputCls}
            />
          </Field>
          <Field label="Email">
            <input
              type="email"
              value={profileEmail}
              onChange={e => setProfileEmail(e.target.value)}
              placeholder="jane@clinic.com"
              className={inputCls}
            />
          </Field>
          <Field label="Phone">
            <input
              type="tel"
              value={profilePhone}
              onChange={e => setProfilePhone(e.target.value)}
              placeholder="(417) 555-0100"
              className={inputCls}
            />
          </Field>
          <SaveButton loading={profileLoading} saved={profileSaved} />
        </form>
      </Section>

      {/* Clinic info — admin/manager only */}
      {canEdit && (
        <Section title="Clinic Information">
          <form onSubmit={saveOrg} className="space-y-4">
            <Field label="Clinic name">
              <input
                type="text"
                value={orgName}
                onChange={e => setOrgName(e.target.value)}
                placeholder="Bridgeway Chiropractic"
                className={inputCls}
              />
            </Field>
            <SaveButton loading={orgLoading} saved={orgSaved} />
          </form>
        </Section>
      )}

      {/* Services — admin/manager only */}
      {canEdit && (
        <Section title="Service Types">
          <div className="space-y-4">
            {/* Existing services */}
            {svcLoading ? (
              <div className="flex justify-center py-4">
                <div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : services.length > 0 ? (
              <div className="space-y-2">
                {services.map(svc => (
                  <div
                    key={svc.id}
                    className="flex items-center justify-between px-4 py-3 bg-[#0c1a2e] border border-gray-800 rounded-lg"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white">{svc.name}</p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {svc.duration_minutes} min · ${Number(svc.price).toFixed(2)}
                      </p>
                    </div>
                    {deleteConfirm === svc.id ? (
                      <div className="flex items-center gap-2 ml-4">
                        <span className="text-xs text-gray-400">Archive?</span>
                        <button
                          onClick={() => archiveService(svc.id)}
                          className="px-2.5 py-1 text-xs font-medium bg-red-500/10 text-red-400 border border-red-500/20 rounded-md hover:bg-red-500/20 transition-colors"
                        >
                          Yes
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(null)}
                          className="px-2.5 py-1 text-xs font-medium text-gray-400 border border-gray-700 rounded-md hover:text-white transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirm(svc.id)}
                        className="ml-4 text-gray-600 hover:text-red-400 transition-colors"
                        title="Archive service"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round"
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 py-2">No services yet — add one below.</p>
            )}

            {/* Add service form */}
            <form onSubmit={addService} className="pt-2 border-t border-gray-800 space-y-3">
              <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Add a service</p>
              <div className="flex flex-wrap gap-3">
                <input
                  type="text"
                  value={newSvcName}
                  onChange={e => setNewSvcName(e.target.value)}
                  placeholder="Service name"
                  className={`${inputCls} flex-1 min-w-36`}
                  required
                />
                <input
                  type="number"
                  value={newSvcDuration}
                  onChange={e => setNewSvcDuration(e.target.value)}
                  min={1}
                  placeholder="Duration (min)"
                  className={`${inputCls} w-36`}
                />
                <input
                  type="number"
                  value={newSvcPrice}
                  onChange={e => setNewSvcPrice(e.target.value)}
                  min={0}
                  step="0.01"
                  placeholder="Price ($)"
                  className={`${inputCls} w-28`}
                />
              </div>
              <button
                type="submit"
                disabled={addingSvc || !newSvcName.trim()}
                className="px-4 py-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-sm font-medium border border-amber-500/20 rounded-lg disabled:opacity-50 transition-colors flex items-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                </svg>
                Add service
              </button>
            </form>
          </div>
        </Section>
      )}
    </div>
  )
}
