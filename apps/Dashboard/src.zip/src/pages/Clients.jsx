import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

export default function Clients() {
  const { profile } = useAuth()
  const navigate   = useNavigate()
  const [clients,  setClients]  = useState([])
  const [loading,  setLoading]  = useState(true)
  const [search,   setSearch]   = useState('')

  useEffect(() => {
    if (!profile?.org_id) return
    fetchClients()
  }, [profile?.org_id])

  async function fetchClients() {
    setLoading(true)
    try {
      const { data } = await supabase
        .from('clients')
        .select('id, name, email, phone, created_at, appointments(id, scheduled_at, amount, status)')
        .eq('org_id', profile.org_id)
        .order('name', { ascending: true })
      setClients(data || [])
    } catch {
      setClients([])
    } finally {
      setLoading(false)
    }
  }

  function computeStats(appts = []) {
    const valid      = appts.filter(a => a.status !== 'cancelled')
    const totalSpent = valid.reduce((s, a) => s + Number(a.amount || 0), 0)
    const sorted     = [...valid].sort((a, b) => new Date(b.scheduled_at) - new Date(a.scheduled_at))
    const lastVisit  = sorted[0]?.scheduled_at ?? null
    return { totalAppts: valid.length, totalSpent, lastVisit }
  }

  const filtered = clients.filter(c =>
    !search ||
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.email ?? '').toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-white">Clients</h1>
          <p className="text-sm text-gray-500 mt-0.5">{clients.length} total</p>
        </div>
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"
            fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Search clients…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 pr-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50 w-56"
          />
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                <th className="text-right px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Appts</th>
                <th className="text-right px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Total Spent</th>
                <th className="text-left px-5 py-3.5 text-xs font-medium text-gray-500 uppercase tracking-wider">Last Visit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/60">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center">
                    <div className="flex justify-center">
                      <div className="w-6 h-6 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
                    </div>
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-gray-500">
                    {search ? 'No clients match your search' : 'No clients yet'}
                  </td>
                </tr>
              ) : (
                filtered.map(client => {
                  const { totalAppts, totalSpent, lastVisit } = computeStats(client.appointments)
                  return (
                    <tr
                      key={client.id}
                      onClick={() => navigate(`/clients/${client.id}`)}
                      className="hover:bg-white/[0.03] cursor-pointer transition-colors"
                    >
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-semibold text-amber-400">
                              {client.name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <span className="text-gray-200 font-medium">{client.name}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-gray-400">{client.email ?? '—'}</td>
                      <td className="px-5 py-3.5 text-gray-400">{client.phone ?? '—'}</td>
                      <td className="px-5 py-3.5 text-right text-gray-200 tabular-nums">{totalAppts}</td>
                      <td className="px-5 py-3.5 text-right text-gray-200 font-medium tabular-nums">
                        ${totalSpent.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-gray-400">
                        {lastVisit
                          ? new Date(lastVisit).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                          : '—'}
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
