import { createContext, useContext, useEffect } from 'react'
import { useAuth } from './AuthContext'

const ThemeContext = createContext(null)

export function ThemeProvider({ children }) {
  const { org } = useAuth()

  useEffect(() => {
    const color = org?.primary_color || '#f59e0b'
    document.documentElement.style.setProperty('--bw-primary', color)
    // Also set RGB values for opacity variants
    const r = parseInt(color.slice(1, 3), 16)
    const g = parseInt(color.slice(3, 5), 16)
    const b = parseInt(color.slice(5, 7), 16)
    document.documentElement.style.setProperty('--bw-primary-rgb', `${r}, ${g}, ${b}`)
  }, [org?.primary_color])

  return (
    <ThemeContext.Provider value={{ primaryColor: org?.primary_color || '#f59e0b' }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  return useContext(ThemeContext)
}
