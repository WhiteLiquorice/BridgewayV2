import { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [session, setSession]   = useState(null)
  const [profile, setProfile]   = useState(null)
  const [org, setOrg]           = useState(null)
  const [loading, setLoading]   = useState(true)

  // Wrapped in try/catch — can never throw or leave loading stuck
  async function loadProfile(userId) {
    if (!userId) { setProfile(null); setOrg(null); return }
    try {
      const { data: prof } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle()
      setProfile(prof ?? null)
      if (prof?.org_id) {
        const { data: orgData } = await supabase
          .from('orgs')
          .select('*')
          .eq('id', prof.org_id)
          .maybeSingle()
        setOrg(orgData ?? null)
      } else {
        setOrg(null)
      }
    } catch {
      // Network error, RLS rejection, etc. — clear state and let app proceed
      setProfile(null)
      setOrg(null)
    }
  }

  useEffect(() => {
    // resolved flag ensures setLoading(false) is called exactly once,
    // whether the session check finishes first or the 5s timeout fires first
    let resolved = false
    function resolve() {
      if (!resolved) { resolved = true; setLoading(false) }
    }

    // Timeout fallback — if loading hasn't cleared in 5s, force it
    const timeout = setTimeout(resolve, 5000)

    supabase.auth.getSession()
      .then(async ({ data: { session } }) => {
        setSession(session)
        await loadProfile(session?.user?.id ?? null)
      })
      .catch(() => {
        // getSession itself failed (e.g. no network on first load)
      })
      .finally(() => {
        clearTimeout(timeout)
        resolve()
      })

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session)
        await loadProfile(session?.user?.id ?? null)
      }
    )
    return () => {
      clearTimeout(timeout)
      subscription.unsubscribe()
    }
  }, [])

  return (
    <AuthContext.Provider value={{ session, user: session?.user ?? null, profile, org, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
